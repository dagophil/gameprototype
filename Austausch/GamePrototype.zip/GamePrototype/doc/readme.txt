When executing the program under Linux the file plugins.cfg and plugins_d.cfg
assumes that all ogre plugins are in the following directory: /usr/local/lib/OGRE
If the following error message occurs please adjust the plugin path.

An exception has occured: OGRE EXCEPTION(7:InternalErrorException): Could not
load dynamic library RenderSystem_GL.  System Error: RenderSystem_GL.so: cannot
open shared object file: No such file or directory in DynLib::load at ...



TODO
